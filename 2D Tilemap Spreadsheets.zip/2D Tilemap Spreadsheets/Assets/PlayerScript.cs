using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterControls : MonoBehaviour
{
    private Rigidbody2D player;

    public float speed = 5.0f;
    public float jumpSpeed = 350.0f;
    public bool isGrounded = true;


    // Start is called before the first frame update
    void Start()
    {
        player = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        player.velocity = new Vector2(0, player.velocity.y);

        //if (Input.GetKey(KeyCode.D))
        if (Input.GetKey(KeyCode.D) || (Input.GetKey(KeyCode.RightArrow)))
        {
            player.velocity += Vector2.right * speed;
        }

        if (Input.GetKey(KeyCode.A) || (Input.GetKey(KeyCode.LeftArrow)))
        {
            player.velocity += Vector2.left * speed;
        }

        if (Input.GetKey(KeyCode.Space) && isGrounded || (Input.GetKey(KeyCode.UpArrow) && isGrounded))
        {
            isGrounded = false;
            player.AddForce(Vector2.up * jumpSpeed);
        }
        
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.tag == "Ground")
        {
            isGrounded = true;
        }

        if (collision.gameObject.tag == "coins")
        {
            Destroy(collision.gameObject);
        }

        if (collision.gameObject.tag == "Death")
        {
            Destroy(collision.gameObject);
            //Destroy(this);  Disables player
            // or this works too
            //Destroy(gameObject);   Removes player
        }
    }
}
